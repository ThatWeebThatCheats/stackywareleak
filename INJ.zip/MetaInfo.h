#pragma once

#define META_GAME "Counter-Strike: Global Offensive"
#define META_CHEATVER "Beta"
#define META_CHEATNAME "AVOZ"

void PrintMetaHeader();