#pragma once

class Globalsh
{
public:

	float OldSimulationTime[65];
};

extern Globalsh globalsh;