#include "Resolver.h"
#include "Ragebot.h"
#include "Hooks.h"
#include "RenderManager.h"
#include "lagcomp.h"


#ifdef NDEBUG
#define XorStr( s ) ( XorCompileTime::XorString< sizeof( s ) - 1, __COUNTER__ >( s, std::make_index_sequence< sizeof( s ) - 1>() ).decrypt() )
#else
#define XorStr( s ) ( s )
#endif

/*
A lot of people didn't get why all this is here, so i will explain.

My idea behind this is to allow people, regardless of preference compared to me, be able to build something of their own
and i want to give them all the tools needed. You got some reversed aw dump stuff here, and a lot of
other things you can use to essentially build any type of fsn resolver you feel like. What's prebuilt is simply
down to my personal preference.
*/


float get_average_lby_standing_update_delta(IClientEntity* player) {
	static float last_update_time[64];
	static float second_laste_update_time[64];
	static float oldlowerbody[64];
	float lby = static_cast<int>(fabs(player->GetEyeAnglesPointer()->y - player->GetLowerBodyYaw()));

	if (lby != oldlowerbody[player->GetIndex()]) {
		second_laste_update_time[player->GetIndex()] = last_update_time[player->GetIndex()];
		last_update_time[player->GetIndex()] = Interfaces::Globals->curtime;
		oldlowerbody[player->GetIndex()] = lby;
	}

	return last_update_time[player->GetIndex()] - second_laste_update_time[player->GetIndex()];
}

bool lby_keeps_updating() {
	return get_average_lby_standing_update_delta;
}

void ResolverSetup::preso(IClientEntity * pEntity)
{
	if (g_menu::window.RageBotTab.preso.GetIndex() == 1)
	{
		pEntity->GetEyeAnglesXY()->x = 89;
	}
	else if (g_menu::window.RageBotTab.preso.GetIndex() == 2)
	{
		pEntity->GetEyeAnglesXY()->x = -89;
	}
	else if (g_menu::window.RageBotTab.preso.GetIndex() == 3)
	{
		pEntity->GetEyeAnglesXY()->x = 0;
	}
	else if (g_menu::window.RageBotTab.preso.GetIndex() == 4)
	{
		float last_simtime[64] = { 0.f };
		float stored_pitch[64] = { 89.f };
		float last_lby[64] = { 0.f };
		float last_lby_delta[64] = { 0.f };
		float large_lby_delta[64] = { 0.f };
		float moving_lby[64] = { 0.f };
		bool  was_moving[64] = { false };

		const auto local = hackManager.pLocal();
		if (!local) return;

		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i) {
			const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));


			if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant()) {
				last_simtime[i] = 0.f;
				stored_pitch[i] = 89.f;
				continue;
			}


			const auto eye = player->GetEyeAnglesXY();
			const auto sim = player->GetSimulationTime();



			auto missed = Globals::fired - Globals::hit;
			while (missed > 5) missed -= 5;
			while (missed < 0) missed += 5;

			auto is_legit = false;
			auto update = false;


			if (sim - last_simtime[i] >= 1)
			{
				stored_pitch[i] = eye->x;
				last_simtime[i] = sim;
			}

			if (Globals::missedshots < 3)
				player->GetEyeAnglesXY()->x = stored_pitch[i];
			else
				player->GetEyeAnglesXY()->x = 89;

		}


	}
}







float GetCurTime(CUserCmd* ucmd) {
	IClientEntity* local_player = hackManager.pLocal();
	static int g_tick = 0;
	static CUserCmd* g_pLastCmd = nullptr;
	if (!g_pLastCmd || g_pLastCmd->hasbeenpredicted) {
		g_tick = (float)local_player->GetTickBase();
	}
	else {
		// Required because prediction only runs on frames, not ticks
		// So if your framerate goes below tickrate, m_nTickBase won't update every tick
		++g_tick;
	}
	g_pLastCmd = ucmd;
	float curtime = g_tick * Interfaces::Globals->interval_per_tick;
	return curtime;
}



bool HasFakeHead(IClientEntity* pEntity) {

	return abs(pEntity->GetEyeAnglesXY()->y - pEntity->GetLowerBodyYaw()) > 35;
}
bool Lbywithin35(IClientEntity* pEntity) {

	if ((pEntity->GetLowerBodyYaw() - 36 < pEntity->GetEyeAnglesXY()->y && pEntity->GetLowerBodyYaw() + 15 > pEntity->GetEyeAnglesXY()->y) || (pEntity->GetLowerBodyYaw() + 36 > pEntity->GetEyeAnglesXY()->y && pEntity->GetLowerBodyYaw() - 15 < pEntity->GetEyeAnglesXY()->y))
		return true;
	else
		return false;

}
bool IsMovingOnGround(IClientEntity* pEntity) {

	return pEntity->GetVelocity().Length2D() > 25.f && pEntity->GetFlags() & FL_ONGROUND;
}



bool IsMovingOnInAir(IClientEntity* pEntity) {

	return !(pEntity->GetFlags() & FL_ONGROUND);
}
bool OnGround(IClientEntity* pEntity) {

	return pEntity->GetFlags() & FL_ONGROUND;
}
bool IsFakeWalking(IClientEntity* pEntity) {

	return IsMovingOnGround(pEntity) && (pEntity->GetVelocity().Length2D() <= 25.0f && pEntity->GetVelocity().Length2D() > 1.1f);
}

inline float RandomFloat(float min, float max)
{
	static auto fn = (decltype(&RandomFloat))(GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomFloat"));
	return fn(min, max);
}
void BETA_LBYBreakerCorrections(IClientEntity* pEntity)
{
	float movinglby[64];
	float lbytomovinglbydelta[64];
	bool onground = pEntity->GetFlags() & FL_ONGROUND;

	if (g_menu::window.RageBotTab.LBYCorrection.GetState())
	{
		lbytomovinglbydelta[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw() - lbytomovinglbydelta[pEntity->GetIndex()];

		if (pEntity->GetVelocity().Length2D() > 6 && pEntity->GetVelocity().Length2D() < 42)
		{
			pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 120;
		}
		else if (pEntity->GetVelocity().Length2D() < 6 || pEntity->GetVelocity().Length2D() > 42) // they are moving
		{
			pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw();
			movinglby[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
		}
		else if (lbytomovinglbydelta[pEntity->GetIndex()] > 50 && lbytomovinglbydelta[pEntity->GetIndex()] < -50 &&
			lbytomovinglbydelta[pEntity->GetIndex()] < 112 && lbytomovinglbydelta[pEntity->GetIndex()] < -112)
		{
			pEntity->GetEyeAnglesXY()->y = movinglby[pEntity->GetIndex()];
		}
		else pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw();
	}
}




static int GetSequenceActivity(IClientEntity* pEntity, int sequence)
{
	const model_t* pModel = pEntity->GetModel();
	if (!pModel)
		return 0;

	auto hdr = Interfaces::ModelInfo->GetStudiomodel(pEntity->GetModel());

	if (!hdr)
		return -1;

	static auto get_sequence_activity = reinterpret_cast<int(__fastcall*)(void*, studiohdr_t*, int)>(Utilities::Memory::FindPatternV2("client.dll", "55 8B EC 83 7D 08 FF 56 8B F1 74 3D"));

	return get_sequence_activity(pEntity, hdr, sequence);
}

static bool stored[128] = { false };
float neweye[128];
float lastLBY[65];
static float storedLBYFromUpdate[65] = { 0.f };
static float staticLBYFromUpdate[65] = { 0.f };
static double oldStoredCurtime[65] = { 0.f };
static bool firstBreak[65] = { false };
static float lastSimtime[65] = { false };

static float pelvisVelocity[65][65] = { 0.0f };
float pelvisMaxVelocityLog[65][6] = { 0.0f };
float pelvisAverageVelocity[65] = { 0.0f };
int pelvisCalculationCounter[125] = { 0 };
static bool didHit = false;
float deltaDiffName[65] = { 0 };
bool lastDeltaOver120[65] = { false };
float saveYaw = 0.f;
static Vector lastPelvis[65] = { Vector(0, 0, 0) };
static Vector yawangle[65] = { Vector(0, 0, 0) };

float NormalizeFloatToAngle(float input)
{
	for (auto i = 0; i < 3; i++) {
		while (input < -180.0f) input += 360.0f;
		while (input > 180.0f) input -= 360.0f;
	}
	return input;
}


bool ResolverSetup::lbyDeltaOver120(int plID)
{

	if (lastDeltaOver120[plID] && pelvisAverageVelocity[plID] > 3.f)
		deltaDiffName[plID] = Interfaces::Globals->curtime;
	else if (pelvisAverageVelocity[plID] > 6.f &&  Interfaces::Globals->curtime - deltaDiffName[plID] > .1f)
	{
		deltaDiffName[plID] = Interfaces::Globals->curtime;
		lastDeltaOver120[plID] = true;
	}
	else if (!lastDeltaOver120[plID] && pelvisAverageVelocity[plID] < 3.f)
		deltaDiffName[plID] = Interfaces::Globals->curtime;
	else if (pelvisAverageVelocity[plID] < 3.f &&  Interfaces::Globals->curtime - deltaDiffName[plID] > .1f)
	{
		deltaDiffName[plID] = Interfaces::Globals->curtime;
		lastDeltaOver120[plID] = false;
	}
	return lastDeltaOver120[plID];
}

//thats spread but still nospread resolver ft.Demn Logic :)

bool isflying(IClientEntity* pEntity)
{
	if (!pEntity->GetFlags() & FL_ONGROUND)
	{
		return true;
	}
	return false;
}
//tick clamp boyyyyyyyyyysssssssss
template<class T, class U>
T iSimTicksClamp(T in, U low, U high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}

bool IsLBYAnimationUpdated(IClientEntity* pEntity)
{
	for (int w = 0; w < 13; w++)
	{
		AnimationLayer prevlayer;
		AnimationLayer currentLayer = pEntity->GetAnimOverlays()[1];
		const int activity = pEntity->GetSequenceActivity(currentLayer.m_nSequence);
		float flcycle = currentLayer.m_flCycle, flprevcycle = currentLayer.m_flPrevCycle, flweight = currentLayer.m_flWeight, flweightdatarate = currentLayer.m_flWeightDeltaRate;
		uint32_t norder = currentLayer.m_nOrder;
		if (activity == ACT_CSGO_IDLE_ADJUST_STOPPEDMOVING)
		{
			return true;
		}
		else if (activity == ACT_CSGO_CLIMB_LADDER)
		{
			return true;
		}
		else if (activity == ACT_CSGO_DEFUSE || activity == ACT_CSGO_DEFUSE_WITH_KIT)
		{
			return true;
		}
		else if (activity == ACT_CSGO_FIRE_PRIMARY)
		{
			return true;
		}
		else if (activity == ACT_CSGO_FLASHBANG_REACTION)
		{
			return true;
		}
		else if (activity == ACT_CSGO_LAND_HEAVY || activity == ACT_CSGO_LAND_LIGHT)
		{
			return true;
		}
		else if (activity == ACT_CSGO_PLANT_BOMB || activity == ACT_CSGO_RELOAD_LOOP)
		{
			return true;
		}

		return false;
	}
	return false;
}



float override_yaw(IClientEntity* player, IClientEntity* local) {
	Vector eye_pos, pos_enemy;
	CalcAngle(player->GetEyePosition(), local->GetEyePosition(), eye_pos);
	if (Render::TransformScreen(player->GetOrigin(), pos_enemy)) {
		if (GUI.GetMouse().x < pos_enemy.x)
			return (eye_pos.y - 90);
		else if (GUI.GetMouse().x > pos_enemy.x)
			return (eye_pos.y + 90);
	}
	return eye_pos.y + 180;
}



bool ResolverSetup::didLBYUpdate(IClientEntity* player)
{
	int curTarget = player->GetIndex();

	double cTime = player->GetSimulationTime() + curTarget;




	for (int s = 0; s < 14; s++)
	{
		auto anim_layer = player->GetAnimOverlay(s);
		if (!anim_layer.m_pOwner)
			continue;
		auto AnimeLayer = &player->GetAnimOverlays()[1];
		auto activity = GetSequenceActivity(player, AnimeLayer->m_nSequence);

		if (activity == -1)
			continue;
		if (activity == 979 && (anim_layer.m_flCycle > 0.862494) && player->GetVelocity().Length2D() < 38.f)
		{

			storedLBYFromUpdate[curTarget] = player->GetLowerBodyYaw();
			ResolverSetup::LBYUpdate[player->GetIndex()] = true;
			oldStoredCurtime[curTarget] = cTime + 1.1;
			return true;
		}
	}

	return false;
}

bool lowerBodyYawUpdated(IClientEntity* pEntity) {
	for (int w = 0; w < 14; w++)
	{
		AnimationLayer currentLayer = pEntity->GetAnimOverlay(w);
		const int activity = GetSequenceActivity(pEntity, currentLayer.m_nSequence);
		float flcycle = currentLayer.m_flCycle, flprevcycle = currentLayer.m_flPrevCycle, flweight = currentLayer.m_flWeight, flweightdatarate = currentLayer.m_flWeightDeltaRate;
		uint32_t norder = currentLayer.m_nOrder;
		if (activity == 973 && flweight == 1.f || activity == 979 && flweight == 1.0f && currentLayer.m_flPrevCycle != currentLayer.m_flCycle)// 961 looks like they shot //flweight seems like right as the animation or right after 972 could be moving
			return true;
	}
	return false;
}
bool didLBYUpdateOver120(IClientEntity* player)
{
	int curTarget = player->GetIndex();

	double cTime = player->GetSimulationTime() + curTarget;




	for (int s = 0; s < 14; s++)
	{
		auto anim_layer = player->GetAnimOverlay(s);
		if (!anim_layer.m_pOwner)
			continue;
		auto AnimeLayer = &player->GetAnimOverlays()[1];
		auto activity = GetSequenceActivity(player, AnimeLayer->m_nSequence);

		if (activity == -1) //If idle animation, skip it
			continue;
		if (activity == 979 && player->GetVelocity().Length2D() < 38.f)
		{
			return true;
		}
	}

	return false;
}




void ResolverSetup::Resolve(IClientEntity* pEntity, int CurrentTarget)
{






#define RandomInt(nMin, nMax) (rand() % (nMax - nMin + 1) + nMin);
	std::string aa_info[64];


	//------bool------//

	std::vector<int> HitBoxesToScan;




	bool MeetsLBYReq;
	bool maybefakehead = 0;

	//------bool------//

	//------float------//



	//------float------//


	//------Statics------//
	static Vector Skip[65];
	static float StaticHeadAngle = 0;

	static bool GetEyeAngles[65]; //Resolve: Frame EyeAngle
	static bool GetLowerBodyYawTarget[65]; //Resolve: LowerBody
	static bool isLBYPredictited[65];
	static bool switch2;

	static float OldLowerBodyYaws[65];
	static float OldYawDeltas[65];
	static float oldTimer[65];








	ResolverSetup::NewANgles[pEntity->GetIndex()] = *pEntity->GetEyeAnglesXY();
	ResolverSetup::newlby[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
	ResolverSetup::newsimtime = pEntity->GetSimulationTime();
	ResolverSetup::newdelta[pEntity->GetIndex()] = pEntity->GetEyeAnglesXY()->y;
	ResolverSetup::newlbydelta[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
	ResolverSetup::finaldelta[pEntity->GetIndex()] = ResolverSetup::newdelta[pEntity->GetIndex()] - ResolverSetup::storeddelta[pEntity->GetIndex()];
	ResolverSetup::finallbydelta[pEntity->GetIndex()] = ResolverSetup::newlbydelta[pEntity->GetIndex()] - ResolverSetup::storedlbydelta[pEntity->GetIndex()];
	if (newlby == storedlby)
		ResolverSetup::lbyupdated = false;
	else
		ResolverSetup::lbyupdated = true;
	//StoreThings(pEntity);

	static float LatestLowerBodyYawUpdateTime[55];

	IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();


	if (pEntity->GetFlags() & FL_ONGROUND)
		MeetsLBYReq = true;
	else
		MeetsLBYReq = false;

	//StoreFGE(pEntity);






	static float time_at_update[65];
	float kevin[64];
	static bool bLowerBodyIsUpdated = false;

	if (pEntity->GetLowerBodyYaw() != kevin[pEntity->GetIndex()])
		bLowerBodyIsUpdated = true;
	else
		bLowerBodyIsUpdated = false;

	if (pEntity->GetVelocity().Length2D() < 1)
	{
		kevin[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();//storing their moving lby for later
		LatestLowerBodyYawUpdateTime[pEntity->GetIndex()] = pEntity->GetSimulationTime() + 1.1;

	}




	bool ismoving; if (pEntity->GetVelocity().Length2D() > 1.1) ismoving = true; else ismoving = false;


	float LBY = pEntity->GetLowerBodyYaw();
	float LBYDelta = pEntity->GetEyeAnglesXY()->y - LBY;

	bool fakespin;
	bool fakespin2;
	bool fakespin4;

	bool lbybreak;
	bool fakespin3;


	if (newlby == storedlby)
		ResolverSetup::lbyupdated = false;
	else
		ResolverSetup::lbyupdated = true;

	if (LatestLowerBodyYawUpdateTime[pEntity->GetIndex()] = pEntity->GetSimulationTime() + 0.4 && pEntity->GetVelocity().Length2D() < 1.0f && FL_ONGROUND)
	{

		if (ResolverSetup::newdelta[pEntity->GetIndex()] < (pEntity->GetEyeAnglesXY()->y + 60) || ResolverSetup::newdelta[pEntity->GetIndex()] > (pEntity->GetEyeAnglesXY()->y - 60))
		{
			if (LatestLowerBodyYawUpdateTime[pEntity->GetIndex()] = pEntity->GetSimulationTime() + 0.2 && pEntity->GetVelocity().Length2D() < 1.0f)
			{
				if (ResolverSetup::newdelta[pEntity->GetIndex()] < ((pEntity->GetEyeAnglesXY()->y + 60) * 2) || ResolverSetup::newdelta[pEntity->GetIndex()] > ((pEntity->GetEyeAnglesXY()->y - 60) * 2))
				{
					fakespin = true;
				}
				else
					fakespin3 = true;

				if ((ResolverSetup::newdelta[pEntity->GetIndex()] + 30) < LBY && (ResolverSetup::newdelta[pEntity->GetIndex()] - 30) > LBY)
				{
					lbybreak = true;
				}
				else
					lbybreak = false;
			}
		}
		if ((((ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y + 25) && (ResolverSetup::newdelta[pEntity->GetIndex()]) > (pEntity->GetEyeAnglesXY()->y + 25)) || (ResolverSetup::newdelta[pEntity->GetIndex()] > (pEntity->GetEyeAnglesXY()->y - 35) && (ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y - 35))) && ResolverSetup::newdelta[pEntity->GetIndex()] > (pEntity->GetEyeAnglesXY()->y + 60) || ResolverSetup::newdelta[pEntity->GetIndex()] < (pEntity->GetEyeAnglesXY()->y - 60))
		{
			fakespin2 = true;
		}
		if ((((ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y + 85) && (ResolverSetup::newdelta[pEntity->GetIndex()]) > (pEntity->GetEyeAnglesXY()->y + 85)) || (ResolverSetup::newdelta[pEntity->GetIndex()] > (pEntity->GetEyeAnglesXY()->y - 85) && (ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y - 85))))
		{
			fakespin4 = true;
		}
		if ((ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y + 20) || ResolverSetup::newdelta[pEntity->GetIndex()] > (pEntity->GetEyeAnglesXY()->y - 20))
		{
			if (LBY != pEntity->GetEyeAnglesXY()->y &&  pEntity->GetEyeAnglesXY()->y <= (LBYDelta + 30) && pEntity->GetEyeAnglesXY()->y >= (LBYDelta - 30))
			{

				lbybreak = true;
				fakespin2 = true;
			}
			else
			{

				fakespin2 = true;
				lbybreak = false;
			}
		}
		if ((LBY != pEntity->GetEyeAnglesXY()->y &&  pEntity->GetEyeAnglesXY()->y <= (LBYDelta + 40) && ((pEntity->GetEyeAnglesXY()->y >= (LBYDelta - 40) && ((ResolverSetup::newdelta[pEntity->GetIndex()]) > (pEntity->GetEyeAnglesXY()->y + 30) || (ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y - 30))) || !((ResolverSetup::newdelta[pEntity->GetIndex()]) < (pEntity->GetEyeAnglesXY()->y + 20) || ResolverSetup::newdelta[pEntity->GetIndex()] > (pEntity->GetEyeAnglesXY()->y - 20)))))
		{
			lbybreak = true;
			fakespin = false;
			fakespin2 = false;
		}
		else
		{
			lbybreak = false;
			fakespin = false;
			fakespin2 = false;
		}
	}


	float moving_lby[64];
	float last_moving_lby[64];

	float moving_lby2[64];
	float last_moving_lby2[64];

	float moving_pitch[64];
	float last_pitch[64];

	float delta = pEntity->GetEyeAnglesXY()->y - pEntity->GetLowerBodyYaw();

	float loglby[64];
	float loggedlby[64];

	if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 1)
	{



		for (int i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		{

			IClientEntity *player = (IClientEntity*)Interfaces::EntList->GetClientEntity(i);

			if (!player || player->IsDormant() || player->GetHealth() < 1 || (DWORD)player == (DWORD)pLocal)
				continue;

			if (!player)
				continue;

			if (pLocal)
				continue;

		}

		if (LatestLowerBodyYawUpdateTime[pEntity->GetIndex()] < pEntity->GetSimulationTime() || bLowerBodyIsUpdated)
		{
			LatestLowerBodyYawUpdateTime[pEntity->GetIndex()] = pEntity->GetSimulationTime() + 1.1;

			switch (Globals::missedshots % 4)
			{
			case 0: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw(); break;
			case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()]; break;
			case 2: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() - 35; break;
			case 3: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 35; break;
			}

		}
		else
		{
			if (pEntity->GetVelocity().Length2D() > 45 & pEntity->GetFlags() & FL_ONGROUND)
			{
				moving_lby[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
				last_moving_lby[pEntity->GetIndex()] = moving_lby[pEntity->GetIndex()];

				pEntity->GetEyeAnglesXY()->y = moving_lby[pEntity->GetIndex()];

			}
			else if (IsMovingOnGround(pEntity))
			{
				switch (Globals::missedshots % 4)
				{
				case 0: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw(); break;
				case 1: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() - 45; break;
				case 2: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw(); break;
				case 3: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 45; break;
				}
			}
			else if (IsFakeWalking(pEntity) && !(pEntity->GetMoveType() & FL_DUCKING))
			{
				switch (Globals::missedshots % 4)
				{
				case 0: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()]; break;
				case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 60; break;
				case 2: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] - 60; break;
				case 3: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 180; break;
				}
			}
			else if (IsMovingOnInAir(pEntity))
			{
				switch (Globals::missedshots % 4) // 
				{
				case 0: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()]; break;
				case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] - 75; break;
				case 2: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 75; break;
				case 3: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 180; break;
				}
			}
			else if (!ismoving && MeetsLBYReq)
			{
				if (Lbywithin35(pEntity))
				{
					if (HasFakeHead(pEntity))
					{
						switch (Globals::missedshots % 5)
						{
						case 0: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()]; break;
						case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 25; break;
						case 2: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] - 25; break;
						case 3: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 15; break;
						case 4: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 145; break;
						}
					}
					else
					{
						switch (Globals::missedshots % 5)
						{
						case 0: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()]; break;
						case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 25; break;
						case 2: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] - 25; break;
						case 3: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 15; break;
						case 4: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 145; break;
						}
					}
				}
				else
				{
					switch (Globals::missedshots % 5)
					{
					case 0: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()]; break;
					case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 25; break;
					case 2: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] - 35; break;
					case 3: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 45; break;
					case 4: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 145; break;
					}
				}


			}
			else
			{
				switch (Globals::missedshots % 5)
				{
				case 0: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw(); break;
				case 1: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] + 25; break;
				case 2: pEntity->GetEyeAnglesXY()->y = last_moving_lby[pEntity->GetIndex()] - 35; break;
				case 3: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() - 45; break;
				case 4: pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 145; break;
				}
			}
		}

	}
	else if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 2)
	{


		float last_simtime[64] = { 0.f };
		float stored_pitch[64] = { 89.f };
		float last_lby[64] = { 0.f };
		float last_lby2[64] = { 0.f };
		float last_lby_delta[64] = { 0.f };
		float large_lby_delta[64] = { 0.f };
		float large_lby_delta2[64] = { 0.f };
		float moving_lby[64] = { 0.f };
		bool  was_moving[64] = { false };

		auto legit = false;
		auto update = false;


		const auto local = hackManager.pLocal();

		if (!local) return;

		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));

			if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant()) {
				last_simtime[i] = 0.f;
				stored_pitch[i] = 89.f;
				last_lby[i] = 0.f;
				last_lby2[i] = 0.f;
				last_lby_delta[i] = 0.f;
				large_lby_delta[i] = 0.f;
				large_lby_delta2[i] = 0.f;
				was_moving[i] = false;
				continue;
			}

			const auto lby = player->GetLowerBodyYaw();
			const auto eye = player->GetEyeAnglesXY();
			const auto sim = player->GetSimulationTime();
			const auto vel = player->GetVelocity().Length2D();

			auto missed = Globals::fired - Globals::hit;
			while (missed > 8) missed -= 8;
			while (missed < 0) missed += 8;


			if (lby != last_lby[i]) {
				update = true;
				auto delta = fabsf(lby - last_lby[i]);
				last_lby_delta[i] = delta;
				if (delta > 90)
				{
					large_lby_delta[i] = delta;
				}
				last_lby[i] = lby;
			}
			auto angle = 0.f;
			if (update)
			{
				if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 145)
				{
					angle = override_yaw(player, local);
				}
				else
					angle = lby;
			}
			if (lby != last_lby2[i]) {
				update = true;
				auto delta = fabsf(lby - last_lby2[i]);
				last_lby_delta[i] = delta;
				if (delta > 80)
				{
					large_lby_delta2[i] = delta;
				}
				last_lby2[i] = lby;
			}

			if (sim - last_simtime[i] >= 1)
			{
				if (sim - last_simtime[i] == 1)
				{

					legit = true;
				}


				last_simtime[i] = sim;
			}





			if (vel > 12)
			{



				moving_lby[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
				last_moving_lby[pEntity->GetIndex()] = moving_lby[pEntity->GetIndex()];

				was_moving[i] = true;

				moving_lby[i] = lby;

				if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 150)
				{
					angle = override_yaw(player, local);
				}
				else
				{
					switch (Globals::missedshots % 5)
					{
					case 0: angle = moving_lby[pEntity->GetIndex()]; break;
					case 1: angle = pEntity->GetLowerBodyYaw() - 20; break;
					case 2: angle = moving_lby[pEntity->GetIndex()] + 25; break;
					case 3: angle = last_moving_lby[pEntity->GetIndex()]; break;
					case 4: angle = moving_lby[pEntity->GetIndex()]; break;
					}
				}


			}
			else
			{

				if (legit)
				{
					if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 145)
					{
						angle = override_yaw(player, local);
					}
					else
					{
						switch (Globals::missedshots % 6)
						{
						case 0: angle = pEntity->GetLowerBodyYaw(); break;
						case 1: angle = last_moving_lby[pEntity->GetIndex()]; break;
						case 2: angle = pEntity->GetLowerBodyYaw() + 35; break;
						case 3: angle = pEntity->GetLowerBodyYaw() - 35; break;
						case 4: angle = pEntity->GetLowerBodyYaw() - 90; break;
						case 5: angle = pEntity->GetLowerBodyYaw() + 35; break;
						}
					}


				}
				else
				{


					if (was_moving[i])
					{
						if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 145)
						{

							angle = override_yaw(player, local);
						}
						else
						{
							switch (Globals::missedshots % 8)
							{
							case 0: angle = moving_lby[i] - 35; break;
							case 1: angle = lby + large_lby_delta[i]; break;
							case 2: angle = lby + last_lby_delta[i]; break;
							case 3: angle = moving_lby[i]; break;
							case 4: angle = lby; break;
							case 5: angle = moving_lby[i] - 90; break;
							case 6: angle = moving_lby[i] + 90; break;
							case 7: angle = last_lby_delta[i]; break;
							}
						}

					}
					else
					{
						if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 145)
						{
							angle = override_yaw(player, local);
						}
						else
						{
							switch (Globals::missedshots % 9)
							{
							case 0: angle = lby + last_lby2[i]; break;
							case 1: angle = large_lby_delta2[i]; break;
							case 2: angle = lby + last_lby_delta[i]; break;
							case 3: angle = lby + large_lby_delta[i]; break;
							case 4: angle = last_moving_lby[pEntity->GetIndex()]; break;
							case 5: angle = angle - 120; break;
							case 6: angle = angle + 120; break;
							case 7: angle = angle - last_lby_delta[i]; break;
							case 8: angle = angle - 180; break;
							}
						}

					}

				}
			}
			player->GetEyeAnglesXY()->y = angle;
		}
	}
	else if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 3)
	{

		float last_simtime[64] = { 0.f };
		float last_lby[64] = { 0.f };
		float last_lby_delta[64] = { 0.f };
		float large_lby_delta[64] = { 0.f };
		float moving_lby[64] = { 0.f };
		bool  was_moving[64] = { false };

		const auto local = hackManager.pLocal();
		if (!local) return;

		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i) {
			const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));


			if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant()) {
				last_simtime[i] = 0.f;

				last_lby[i] = 0.f;
				last_lby_delta[i] = 0.f;
				large_lby_delta[i] = 0.f;
				was_moving[i] = false;
				continue;
			}

			//grab values from player
			const auto lby = player->GetLowerBodyYaw();
			const auto eye = player->GetEyeAnglesXY();
			const auto sim = player->GetSimulationTime();
			const auto vel = player->GetVelocity().Length2D();

			//auto missed = Globals::missedshots;
			auto missed = Globals::fired - Globals::hit;
			while (missed > 5) missed -= 5;
			while (missed < 0) missed += 5;

			auto is_legit = false;
			auto update = false;


			if (sim - last_simtime[i] >= 1) {
				if (sim - last_simtime[i] == 1)
				{

					is_legit = true;
				}


				last_simtime[i] = sim;
			}


			if (lby != last_lby[i])
			{
				update = true;
				auto delta = fabsf(lby - last_lby[i]);
				last_lby_delta[i] = delta;
				if (delta > 90)
				{
					large_lby_delta[i] = delta;
				}
				last_lby[i] = lby;
			}


			auto angle = 0.f;
			if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 60) {
				angle = override_yaw(player, local);
			}
			if (is_legit)
			{
				if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
				{
					angle = override_yaw(pEntity, pLocal);
				}
				else
					angle = eye->y;
			}
			else if (update)
			{
				if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()) && vel < 145)
				{
					angle = override_yaw(player, local);
				}
				else
					angle = lby;
			}

			else if (vel > 35)
			{
				angle = lby;
				moving_lby[i] = lby;
				was_moving[i] = true;
			}
			else if (was_moving[i])
			{
				if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
				{
					angle = override_yaw(pEntity, pLocal);
				}
				else
				{
					switch (missed) {
					case 0: angle = moving_lby[i]; break;
					case 1: angle = lby + large_lby_delta[i]; break;
					case 2: angle = lby + last_lby_delta[i]; break;
					case 3: angle = moving_lby[i]; break;
					case 4: angle = moving_lby[i] + 180; break;
					default: angle = lby - 120;
					}
				}
			}
			else {
				if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
				{
					angle = override_yaw(pEntity, pLocal);
				}
				else
				{
					switch (missed) {
					case 0:angle = lby - 120; break;
					case 1: angle = lby + large_lby_delta[i]; break;
					case 2: angle = lby + last_lby_delta[i]; break;
					case 3: angle = moving_lby[i] - 35; break;
					case 4: angle = moving_lby[i] + 145; break;
					default: angle = lby + (90 * (missed + 1));
					}
				}

			}


			player->GetEyeAnglesXY()->y = angle;
		}
	}

	else if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 4)
	{


		CUserCmd* pCmd;
		bool  was_moving[64] = { false };

		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i) {


			auto angle = 0.f;
			if (pEntity->GetVelocity().Length2D() > 1)
			{
				if (pEntity->GetFlags() & FL_ONGROUND)
				{

					if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
					{
						angle = override_yaw(pEntity, pLocal);
					}
					else
					{
						switch (Globals::missedshots % 4)
						{
						case 0: angle = pEntity->GetLowerBodyYaw(); break;
						case 1: angle = last_moving_lby[pEntity->GetIndex()] - 20; break;
						case 2: angle = pEntity->GetLowerBodyYaw() + 15; break;
						case 3: angle = moving_lby[pEntity->GetIndex()] + 25; break;
						}
					}

				}
				else
				{
					switch (Globals::missedshots % 4)
					{
					case 0: angle = pEntity->GetLowerBodyYaw(); break;
					case 1: angle = pEntity->GetLowerBodyYaw() - 45; break;
					case 2: angle = pEntity->GetLowerBodyYaw() - 180; break;
					case 3: angle = pEntity->GetLowerBodyYaw() + 135; break;
					}
				}

			}
			else
			{
				if (Lbywithin35(pEntity))
				{

					if (HasFakeHead(pEntity))
					{
						if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
						{
							angle = override_yaw(pEntity, pLocal);
						}
						else
						{
							switch (Globals::missedshots % 7)
							{
							case 0: angle = last_moving_lby[pEntity->GetIndex()] + 20; break;
							case 1: angle = last_moving_lby[pEntity->GetIndex()] - 45; break;
							case 2: angle = pEntity->GetLowerBodyYaw();  break;
							case 3: angle = angle - pEntity->GetLowerBodyYaw(); break;
							case 4: angle = (angle + pEntity->GetLowerBodyYaw()) - 120; break;
							case 5: angle = (angle + pEntity->GetLowerBodyYaw()) + 120; break;
							case 6: angle = (angle - pEntity->GetLowerBodyYaw()) - (150 - rand() % 30); break;
							}
						}
					}
					else
					{
						if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
						{
							angle = override_yaw(pEntity, pLocal);
						}
						else
						{
							switch (Globals::missedshots % 7)
							{
							case 0: angle = last_moving_lby[pEntity->GetIndex()] - 25; break;
							case 1: angle = last_moving_lby[pEntity->GetIndex()] + 25; break;
							case 2: angle = pEntity->GetLowerBodyYaw() - 119; break;
							case 3: angle = angle - 90; break;
							case 4: angle = angle - 60; break;
							case 5: angle = (angle + pEntity->GetLowerBodyYaw()) + 120; break;
							case 6: angle = (angle - pEntity->GetLowerBodyYaw()) - (150 - rand() % 30); break;
							}
						}
					}

				}
				else
				{

					if (was_moving[i])
					{
						if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
						{
							angle = override_yaw(pEntity, pLocal);
						}
						else
						{
							switch (Globals::missedshots % 7)
							{
							case 0: angle = last_moving_lby[pEntity->GetIndex()] - 15; break;
							case 1: angle = last_moving_lby[pEntity->GetIndex()] + 40; break;
							case 2: angle = pEntity->GetLowerBodyYaw(); break;
							case 3: angle = pEntity->GetLowerBodyYaw() - 119; break;
							case 4: angle = pEntity->GetLowerBodyYaw() + 119; break;
							case 5: angle = angle - pEntity->GetLowerBodyYaw(); break;
							case 6: angle = angle - last_moving_lby[pEntity->GetIndex()]; break;
							}
						}
					}
					else
					{
						if (GetAsyncKeyState(g_menu::window.RageBotTab.Nadaaa.GetKey()))
						{
							angle = override_yaw(pEntity, pLocal);
						}
						else
						{
							switch (Globals::missedshots % 7)
							{
							case 0: angle = pEntity->GetLowerBodyYaw() - 60; break;
							case 1: angle = angle - 90; break;
							case 2: angle = angle + 50; break;
							case 3: angle = pEntity->GetLowerBodyYaw() + 10; break;
							case 4: angle = angle - pEntity->GetLowerBodyYaw(); break;
							case 5: angle = angle - 90; break;
							case 6: angle = angle + 180; break;
							}
						}

					}

				}

			}
			pEntity->GetEyeAnglesXY()->y = angle;
		}
	}
	//from here new resolver for gays :)
		else if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 5)
		{
			// Created by DemN ( it is gay but still not bad right ? )
			int idx = pEntity->GetIndex();

			static float lby[64] = { 99.f };
			static float oldlby[64] = { 0.f };
			static float StoredAng[64] = { 0.f };

			float length2d = pEntity->GetVelocity().Length2D();

			lby[idx] = *pEntity->GetLowerBodyYawTarget();

			if (length2d > 0.1f && !isflying(pEntity)) {
				pEntity->GetEyeAnglesXY()->y = lby[idx];
			}
			else
			{
				if (lby[idx] != oldlby[idx])
				{
					pEntity->GetEyeAnglesXY()->y = lby[idx];
				}
				else
				{
					if (fabs(pEntity->GetEyeAnglesXY()->y - lby[idx]) <= 45.f)
					{
						// ok. It's May be real ang.
						StoredAng[idx] = pEntity->GetEyeAnglesXY()->y;
					}
					else if (fabs(pEntity->GetEyeAnglesXY()->y - lby[idx]) > 45.f && fabs(pEntity->GetEyeAnglesXY()->y - lby[idx]) < 92.f)
					{
						pEntity->GetEyeAnglesXY()->y = StoredAng[idx];
					}
					else if (fabs(pEntity->GetEyeAnglesXY()->y - lby[idx]) == 180.f)
					{
						pEntity->GetEyeAnglesXY()->y = lby[idx];
					}
					else
					{
						pEntity->GetEyeAnglesXY()->y = StoredAng[idx];
					}
				}

				oldlby[idx] = lby[idx];
			}
		}

		else if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 6)
		{
			// Created by Demn ( Second one ) maybe own skids maybe not

			/* bb own by Demn , noobs :3 */
			int idx = pEntity->GetIndex();

			static float lby[64] = { 99.f };
			static float oldlby[64] = { 0.f };
			static float StoredAng[64] = { 0.f };
			static float lastMoveLBY[64] = { 0.f };

			static int chockedTicksByMoving[64] = { 0 };
			static int chockedTicksByStanding[64] = { 0 };

			static float pEntOldSimTime[64] = { -1.f };
			static float fSimTimeDelta[64] = { -1.f };

			/*     time block      */
			if (pEntity->GetSimulationTime() != pEntOldSimTime[idx])
			{
				fSimTimeDelta[idx] = pEntity->GetSimulationTime() - pEntOldSimTime[idx];
			}
			pEntOldSimTime[idx] = pEntity->GetSimulationTime();


			/* network logic */
			float flTickInterval = 1.f / Interfaces::Globals->interval_per_tick;
			int iTickCount = TIME_TO_TICKS(Interfaces::Globals->curtime);

			INetChannelInfo* nci = Interfaces::Engine->GetNetChannelInfo();	// fixme: is offset valid?

			float flDeltaTime = ((floorf(((nci->GetAvgLatency(FLOW_INCOMING) + nci->GetAvgLatency(FLOW_OUTGOING)) * flTickInterval) + 0.5) + iTickCount + 1) * Interfaces::Globals->interval_per_tick) - pEntity->GetSimulationTime();

			if (flDeltaTime > 1.f)
				flDeltaTime = 1.f;

			int iSimulatedTicks = iSimTicksClamp(floorf((fSimTimeDelta[idx] * flTickInterval) + 0.5), 1, 15); // How many ticks entity is choking? it's mostly constant value
			int iDeltaTicks = TIME_TO_TICKS(flDeltaTime);

			int iSimTimeDif = iDeltaTicks - iSimulatedTicks;	// how many ticks entity would choke.


																/* ENTITY CHOKE LOGIC */
			static bool isEntityChocking[64] = { false };
			if (iSimTimeDif > 0)
			{
				isEntityChocking[idx] = true;
			}
			else
			{
				isEntityChocking[idx] = false;
			}


			/* RESOLVING ENTITIES */
			float length2d = pEntity->GetVelocity().Length2D();

			lby[idx] = *pEntity->GetLowerBodyYawTarget();

			if ((pEntity->GetFlags() & FL_DUCKING) && length2d > 1.6f)
			{
				pEntity->GetEyeAnglesXY()->y = lby[idx];
				lastMoveLBY[idx] = lby[idx];
				chockedTicksByMoving[idx] = iSimulatedTicks;
			}
			else if ((length2d > 3.6f && length2d < 6.f) || (length2d > 37.1f && !isflying(pEntity))) {
				pEntity->GetEyeAnglesXY()->y = lby[idx];
				lastMoveLBY[idx] = lby[idx];
				chockedTicksByMoving[idx] = iSimulatedTicks;
			}
			else if (length2d > 6.f && length2d < 37.f && !(pEntity->GetFlags() & FL_DUCKING))
			{
				pEntity->GetEyeAnglesXY()->y = lby[idx];
				if (fabs(pEntity->GetEyeAnglesXY()->y - lby[idx]) < 35.f)
				{
					pEntity->GetEyeAnglesXY()->y = pEntity->GetEyeAnglesXY()->y;
				}
			}
			else
			{
				chockedTicksByStanding[idx] = iSimulatedTicks;

				/* While entity is chocking, He can't use FAKE angles. So we need to filter pEntity->GetEyeAnglesXY()->y */
				//if (isEntityChocking[idx])
				//{
				// real ang???
				//	StoredAng[idx] = pEntity->GetEyeAnglesXY()->y * (-1);
				//}

				if (oldlby[idx] != lby[idx] && IsLBYAnimationUpdated(pEntity)) //animations boys
				{
					pEntity->GetEyeAnglesXY()->y = lby[idx];
				}
				else
				{
					/* BLOCK OF NOT PERFECT BUT IN SOME WAYS GOOD RESOLVER */
					if (fabs(lastMoveLBY[idx] - pEntity->GetEyeAnglesXY()->y) < 51.f)	// 34.f
					{
						StoredAng[idx] = pEntity->GetEyeAnglesXY()->y;
					}

					if (fabs(lastMoveLBY[idx] - pEntity->GetEyeAnglesXY()->y * (-1)) < 51.f)
					{
						StoredAng[idx] = pEntity->GetEyeAnglesXY()->y * (-1);
					}
					/* END OF BLOCK */

					pEntity->GetEyeAnglesXY()->y = StoredAng[idx];
				}
				oldlby[idx] = lby[idx];
			}
		}
}






class PlayerList
{
public:

	IClientEntity * pLocalEz = hackManager.pLocal();
	class CPlayer
	{
	public:
		Vector ShootPos[125];
		int index = -1;
		IClientEntity* entity;
		Vector reset = Vector(0, 0, 0);
		float lastsim = 0;
		Vector lastorigin = Vector(0, 0, 0);
		std::vector< float > pastangles;
		int ScannedNumber = 0;
		int BestIndex = 0;
		float difference = 0.f;
		float Backtrack[360];
		float flLastPelvisAng = 0.f;
		float flEyeAng = 0.f;
		float resolved = 0.f;
		float posedifference = 0.f;
		Hitbox* box;

		CPlayer(IClientEntity* entity, int index, int lastsim) : entity(entity), index(index), lastsim(lastsim)
		{
		}
	};

private:
	std::vector< CPlayer > Players;
public:
	void Update()
	{
		for (int i = 0; i < Players.size(); i++)
		{
			if (Players[i].entity == nullptr)
			{
				Players.erase(Players.begin() + i);
				continue;
			}
			if (Players[i].entity == pLocalEz)
			{
				Players.erase(Players.begin() + i);
				continue;
			};
		}
	}

	void UpdateSim()
	{
		Update();
		for (int i = 0; i < Players.size(); i++)
		{
			Players[i].lastsim = Players[i].entity->GetSimulationTime();
		}
	}

	void AddPlayer(IClientEntity* ent)
	{
		Players.emplace_back(CPlayer(ent, ent->GetIndex(), ent->GetSimulationTime()));
	}

	CPlayer* FindPlayer(IClientEntity* ent)
	{
		for (int i = 0; i < Players.size(); i++)
			if (Players[i].index == ent->GetIndex())
				return &Players[i];
		AddPlayer(ent);
		return FindPlayer(ent);
	}
} plist;




bool backtrackthis;
int velocity;
#define lerpticks rand() / 420 / velocity - 420 * 0

class pEntity
{
public:
	int ViewAngles;
	int Velocity;
	int LBY;
	int EyeAngles;
	bool InAir;
	bool Forceatek;
	int tickcount;
};


void BackTrack()
{
	pEntity* pLocal;
	pEntity* player;
	player->tickcount = player->Velocity / lerpticks * 0 + 420 - player->ViewAngles;
}

bool Baim;
bool HsOnly;
int BruteForce;
bool lbyexposed;
bool abouttoland;
int OldAngles;
float GetEyeAnglesXY;
float UnresolvedAngle[64]; //Can't combine with next statement because otherwise huge {}; with values.
float LBYEyeDelta; //This is for a later resolver that is not mine.
float FinalAngle[64]; //Value to set after resolving is done.
float MovingLBY[64]; //Value to be used if we can't resolve entity.
float StoredLBY[64]; //This will be compared to BrokenLBY.
float BlackListedAngles[64][3]; //A multidimensional array for blacklisting angles, will be reset upon round end.
float BrokenLBY[64]; //Value to be assigned if the entity is fakewalking.
float LowerBodyTargetToSubtract[64]; //This is for a later statement.
bool  BrokenLBYHasValue[64]; //Failsafe to make sure we don't assign the entity's eye angles to a garbage value.
bool  BlackListedAnglesHasValue[64][3]; //This must be multidimensional, as [0][0] might have a value, but [0][1] might not!
bool  ResolvedStatus[64]; //If we log an animation based LBY update, we know for sure that we have resolved the entity (if the entity is using a static angle).
bool  DidWeUseAnimation[64]; //For keeping track of the stupid number of sequence related variables.
static unsigned short BlackListCounter[64]; //This is for keeping track of the second digit in the multi dimensional arrays. Due to the nature of this, only the most recent blacklisted angle will not be shot at, it will suffice though
static unsigned short SequenceCounter[64]; //This is for keeping track of the subtraction of LowerBodyTargetToSubtract.

namespace Menu
{
	namespace Vars
	{
		bool BruteForce;
	}
}
bool onground;
bool lbybroken;




void ezonetap(Vector* & Angle, PlayerList::CPlayer* Player)
{
	pEntity* pLocal;
	pEntity* player;
	Player->reset.y = Angle->y;
	for (int i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		if (g_menu::window.RageBotTab.AimbotResolver.GetIndex() == 1)
			//
			if (player->InAir && !HsOnly)
			{
				Baim = true;
			}
			else if (player->InAir && HsOnly)
			{
				if (Menu::Vars::BruteForce)
				{
					BruteForce = true;
					if (Angle->y != Player->resolved)
					{
					}
					else
					{
						if (abouttoland)
						{
							Sleep(2);
							pLocal->Forceatek = true;
						}
					}
				}
				else
				{
					onground = true;
				}

				if (lbyexposed)
				{
					pLocal->Forceatek = true;
				}
				else
				{
					int delta = player->ViewAngles - player->LBY;
					if (delta > 29)
					{
						bool lbybroken;
						lbybroken = true;
					}

					if (onground)
					{
						if (player->Velocity > 0)
						{
							player->EyeAngles = player->LBY;
						}
						else
						{
							lbybroken = true;
						}


						if (lbybroken)
						{
							if (Menu::Vars::BruteForce)
							{
								BruteForce = true;
								if (Globals::missedshots >= 1 && Globals::missedshots <= 1)
									if (Angle->y != Player->resolved)
									{
									}
									else
									{
										Sleep(1.1);
										lbyexposed = true;
										player->EyeAngles = OldAngles;
									}
							}


							if (lbyexposed)
							{
								pLocal->Forceatek = true;
							}
							else
							{
								int delta = player->ViewAngles - player->LBY;
								if (delta > 29)
								{
									bool lbybroken;
									lbybroken = true;

								}

								if (lbybroken)
									player->ViewAngles = player->ViewAngles + delta;
							}
						}
					}
				}
			}
}




int IClientEntity::GetSequenceActivity(int sequence)
{
	auto hdr = Interfaces::ModelInfo->GetStudiomodel(this->GetModel());

	if (!hdr)
		return -1;

	static auto getSequenceActivity = (DWORD)(Utilities::Memory::FindPatternV2("client.dll", "55 8B EC 83 7D 08 FF 56 8B F1 74"));
	static auto GetSequenceActivity = reinterpret_cast<int(__fastcall*)(void*, studiohdr_t*, int)>(getSequenceActivity);

	return GetSequenceActivity(this, hdr, sequence);
}



bool IsBreakingLBY120(IClientEntity* pEntity)
{
	for (int w = 0; w < 13; w++)
	{
		AnimationLayer prevlayer;
		AnimationLayer currentLayer = pEntity->GetAnimOverlays()[1];
		const int activity = pEntity->GetSequenceActivity(currentLayer.m_nSequence);
		float flcycle = currentLayer.m_flCycle, flprevcycle = currentLayer.m_flPrevCycle, flweight = currentLayer.m_flWeight, flweightdatarate = currentLayer.m_flWeightDeltaRate;
		uint32_t norder = currentLayer.m_nOrder;
		if (activity == ACT_CSGO_IDLE_ADJUST_STOPPEDMOVING || activity == ACT_CSGO_IDLE_TURN_BALANCEADJUST && flweight >= .99 && currentLayer.m_flPrevCycle != currentLayer.m_flCycle)
		{
			float flanimTime = currentLayer.m_flCycle, flsimtime = pEntity->GetSimulationTime();

			return true;//force lby-180?
		}
		prevlayer = currentLayer;
		return false;
	}
	return false;
}
bool IsResolvableByLBY(IClientEntity* pEntity)
{
	for (int w = 0; w < 13; w++)
	{
		AnimationLayer prevlayer;
		AnimationLayer currentLayer = pEntity->GetAnimOverlays()[1];
		const int activity = pEntity->GetSequenceActivity(currentLayer.m_nSequence);
		float flcycle = currentLayer.m_flCycle, flprevcycle = currentLayer.m_flPrevCycle, flweight = currentLayer.m_flWeight, flweightdatarate = currentLayer.m_flWeightDeltaRate;
		uint32_t norder = currentLayer.m_nOrder;
		if (activity == 979 && currentLayer.m_flWeight == 0.f && currentLayer.m_flPrevCycle != currentLayer.m_flCycle)
		{
			return true;
		}
		prevlayer = currentLayer;
	}
	return false;
}




void ResolverSetup::OverrideResolver(IClientEntity* pEntity)
{

	bool MeetsLBYReq;
	if (pEntity->GetFlags() & FL_ONGROUND)
		MeetsLBYReq = true;
	else
		MeetsLBYReq = false;

	int OverrideKey = g_menu::window.RageBotTab.SomeShit.GetKey();

	if (g_menu::window.RageBotTab.SomeShit.GetKey());
	{
		if (GetAsyncKeyState(g_menu::window.RageBotTab.SomeShit.GetKey()))
		{
			pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() - 180.f;

			{
				resolvokek::resolvemode = 2;
				if (Globals::missedshots > 4 && Globals::missedshots < 5)
				{
					if (MeetsLBYReq && lbyupdated)
					{
						pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw();
					}
					else if (!MeetsLBYReq && lbyupdated)
					{
						switch (Globals::Shots % 4)
						{
						case 1:
							pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 180.f;
							break;
						case 2:
							pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() + 90.f;
							break;
						case 3:
							pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() - 90.f;
							break;
						case 4:
							pEntity->GetEyeAnglesXY()->y = pEntity->GetLowerBodyYaw() - 180.f;
							break;
						}
					}
				}
			}
		}
	}
}




void ResolverSetup::StoreFGE(IClientEntity* pEntity)
{
	ResolverSetup::storedanglesFGE = pEntity->GetEyeAnglesXY()->y;
	ResolverSetup::storedlbyFGE = pEntity->GetLowerBodyYaw();
	ResolverSetup::storedsimtimeFGE = pEntity->GetSimulationTime();
}

void ResolverSetup::StoreThings(IClientEntity* pEntity)
{
	ResolverSetup::StoredAngles[pEntity->GetIndex()] = *pEntity->GetEyeAnglesXY();
	ResolverSetup::storedlby[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
	ResolverSetup::storedsimtime = pEntity->GetSimulationTime();
	ResolverSetup::storeddelta[pEntity->GetIndex()] = pEntity->GetEyeAnglesXY()->y;
	ResolverSetup::storedlby[pEntity->GetIndex()] = pEntity->GetLowerBodyYaw();
}

void ResolverSetup::CM(IClientEntity* pEntity)
{
	for (int x = 1; x < Interfaces::Engine->GetMaxClients(); x++)
	{

		pEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(x);

		if (!pEntity
			|| pEntity == hackManager.pLocal()
			|| pEntity->IsDormant()
			|| !pEntity->IsAlive())
			continue;

		ResolverSetup::StoreThings(pEntity);
	}
}